PX4Flow Firmware
====

PX4FLOW Board Firmware

Project:
http://pixhawk.org

Dev guide / toolchain installation:
http://pixhawk.org/dev/px4flow

To build, run:

  make

To flash via the PX4 bootloader (first run this command, then connect the board):

  make upload-usb