#ifndef _task_control_h_
#define _task_control_h_

#include <rtthread.h>
#include "global_define.h"

void TaskControl(void *p_arg);

extern struct rt_thread Thread_TaskControl;
extern char TaskControl_Stack[TASK_CONTROL_STK_SIZE];

#endif

