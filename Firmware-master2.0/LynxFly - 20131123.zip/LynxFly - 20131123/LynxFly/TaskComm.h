#ifndef _task_comm_h_
#define _task_comm_h_

#include <rtthread.h>
#include "global_define.h"

void TaskComm(void *p_arg);

extern struct rt_thread Thread_TaskComm;
extern char TaskComm_Stack[TASKComm_STK_SIZE];
extern int FD_printf(const char *fmt, ...);

#endif

