#ifndef _task_notify_h_
#define _task_notify_h_

#include <rtthread.h>
#include "global_define.h"

void TaskNotify(void *p_arg);

extern struct rt_thread Thread_TaskNotify;
extern char TaskNotify_Stack[TASK_NOTIFY_STK_SIZE];

#endif

