#ifndef _task_imu_h_
#define _task_imu_h_

#include <rtthread.h>
#include "global_define.h"

void TaskIMU(void *p_arg);
static float invSqrt(float x);

extern struct rt_thread Thread_TaskIMU;
extern char TaskIMU_Stack[TASK_IMU_STK_SIZE];

#endif

