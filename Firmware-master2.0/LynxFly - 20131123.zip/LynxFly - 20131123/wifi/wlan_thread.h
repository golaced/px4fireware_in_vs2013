/*
 * Copyright ?Marvell International Ltd. and/or its affiliates, 2003-2006
 */

#ifndef	__WLAN_THREAD_H_
#define	__WLAN_THREAD_H_

#include <rtthread.h>

// #define WakeUpINT (0x01<<3)

#endif
