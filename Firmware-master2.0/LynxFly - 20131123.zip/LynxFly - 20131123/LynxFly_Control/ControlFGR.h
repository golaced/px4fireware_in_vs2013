#ifndef _ControlFGR_h_
#define _ControlFGR_h_


float ControlFGR(float CDataYr[], float CDataY[], float CDataU[], float F[], int lengthF, float G[], int lengthG, float R[], int lengthR);


#endif
